﻿$axure.internal(function($ax) {
    var _globals = $ax.globals = {};

    $ax.globals.MaxZIndex = 1000;
    $ax.globals.MinZIndex = -1000;
    
});